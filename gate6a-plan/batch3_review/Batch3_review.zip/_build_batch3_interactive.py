# -*- coding: utf-8 -*-
"""Batch 3 圈选台生成器 —— VLM 出草稿，人点选确认，机器绝不直接产出 Gold。

与 Batch 2 的关系
------------------
完全复用 Batch 2 的判定内核（`_build_batch2_viewer` 的表格定位/裁剪、
`_build_batch2_interactive` 的 symbol 收敛 / 参数名补齐 / 置信度合成），
只多做两件事：

  1. **只要 3~5 行核心参数**。Batch 2 一件能出十几行，人核到后面会疲。
     这里按 `CORE_ORDER` 打分，每件只留最核心的 3~5 行（供电、温度、电流、功耗…），
     其余行**不丢证据**，只记进 `_dropped` 供复核时追问。
  2. **显式标 low_confidence**。低于阈值的行在 notes 里写 `low_confidence`，
     人可以在 Excel 里按这个词直接筛出来对图。标记归标记，
     `row_status` 一律仍是 DRAFT_AWAITING_HUMAN_CONFIRM ——
     机器无权替人确认。

输出的 CSV 与 HTML 都是**草稿**，不是 Gold。
"""
from __future__ import print_function

import argparse
import csv
import re
import sys
from pathlib import Path

import fitz

import _build_batch2_viewer as B
import _build_batch2_interactive as I2
import _draft_extract as X
from _vl_extract import extract_rows as vl_extract

PREP = Path(__file__).resolve().parent
WORKING = PREP / "Gold_Set_v1.1_WORKING.csv"

OUT_CSV = PREP / "Batch3_DRAFT.csv"
OUT_HTML = PREP / "Batch3_Viewer.html"
REPORTS = PREP / "annotation_reports"

THRESH = I2.THRESH          # 0.85，与 Batch 2 同源，不另起一个阈值
WARN = "low_confidence"     # 人能在 Excel 里直接搜的词

COLS = B.COLS + ["confidence_score"]
KIND_CN = dict(B.KIND_CN)
KIND_CN["ROC"] = "Recommended Operating Conditions"

# Batch 3 多扫一类表：Recommended Operating Conditions。
# 为什么 Batch 2 没扫：那批要的是"能不能抽对 MIN/TYP/MAX"，ROC 表通常只有单值；
# 但这一轮人要的是**核心参数**，供电电压与工作温度恰恰最常出现在 ROC 里，
# 只扫 AMR/ELC 会整件交不出温度行（V319 就是这种：AMR 里没有 TA）。
KINDS = ("AMR", "ROC", "ELC")

# Batch 2 已定稿的 6 件，绝不再进 Batch 3
DONE = {"V097", "V101", "V111", "V145", "V162", "V349"}

# 第一梯队：原 Batch 1 名单（5 件普通文本型）+ 1 件复杂参数表。
# 选它们打头的原因：表格结构最规整，先用它们校准"核心 3~5 行"的取舍标准，
# 再去碰多级表头/跨页那批硬骨头。
BATCH1 = ["V319", "V304", "V199", "V336", "V173", "V345"]

# 供电电压符号。旧版写的是 `^v(cc|dd|s)\b|\bv(cc|dd)\b`：
# `\b` 要求 VDD 后面紧跟非单词字符，可 VDD_CORE / VDDR_CORE / VDDSHV5
# 的后缀以下划线或字母开头，全都是单词字符，词边界根本不成立 ——
# 于是这些行被判成 pri=99 的非核心参数，pick_core 直接丢掉。
# 现在改成「VCC / VDD / VS + 任意字母数字下划线后缀」，另兼容
# AVDD / DVDD / IOVDD 这类带前缀的写法；参数名里的 supply voltage 仍照旧。
SUPPLY_RX = re.compile(
    r"supply\s+voltage|power[- ]supply\s+voltage"
    r"|\bv(?:cc|dd|s)[a-z0-9_]*\b"
    r"|\b[a-z]{1,3}v(?:cc|dd)[a-z0-9_]*\b",
    re.I)

# 核心参数优先级。数字越小越先留；命不中的行排在后面。
# 只收这几类：供电、温度（工作/存储/结温）、电流（输出/输入）、功耗、输入电压。
CORE_ORDER = [
    # 以下几条的符号分支原先也用了 `^` 锚。core_rank() 拼的是
    # 「parameter_name + 空格 + symbol」，串几乎不以符号开头，
    # `^t\s*j\b` 之类永远命中不了符号位（TJ 因此被判 pri=99 漏掉）。
    # 与供电的 `\b` 是同一类缺陷，一并改成词边界锚。
    (SUPPLY_RX, 1, "供电电压"),
    (re.compile(r"operating\s+(free[- ]air\s+)?temperature|ambient\s+temperature"
                r"|\bt\s*a\b", re.I), 2, "工作温度"),
    (re.compile(r"storage\s+temperature|\bt\s*stg\b", re.I), 3, "存储温度"),
    (re.compile(r"junction\s+temperature|\bt\s*j\b", re.I), 4, "结温"),
    (re.compile(r"(continuous\s+)?output\s+current|\bi\s*o\b", re.I), 5, "输出电流"),
    (re.compile(r"input\s+current|\bi\s*i\b", re.I), 6, "输入电流"),
    (re.compile(r"power\s+dissipation", re.I), 7, "功耗"),
    (re.compile(r"input\s+voltage|\bv\s*i\b", re.I), 8, "输入电压"),
]


def has_num(r):
    """三个数值列里至少有一个非空。"""
    return any((r.get(k) or "").strip()
               for k in ("min_value", "typ_value", "max_value"))


def core_rank(r):
    """给一行打核心度：(优先级, 有没有数值, 置信度)。数值齐的先留。"""
    name = (r.get("parameter_name") or "") + " " + (r.get("symbol") or "")
    pri = 99
    for rx, p, _cn in CORE_ORDER:
        if rx.search(name):
            pri = p
            break
    try:
        conf = float(r.get("confidence_score") or 0)
    except ValueError:
        conf = 0.0
    # 没有数值的核心参数排在"有数值的非核心参数"后面：
    # 人要先看到能核的数，空行放最后面再去补。
    return (pri, 0 if has_num(r) else 1, -conf)


def pick_core(rows, lo=3, hi=5):
    """每件只留最核心的 3~5 行，其余返回给调用方做记录，不落盘。

    V003 事故后加的闸门：一件里若连一行「命中 CORE_ORDER 且带数值」都没有，
    说明定位到的是术语解释页/线图/错表，此时**整件不落草稿**。
    老版会把 5 行无参数名的术语条目凑数交给人，人得先删行再核，
    等于把定位错误伪装成"低置信度草稿"，这是最坏的一种 Fail-Open。
    """
    ranked = sorted(rows, key=core_rank)
    usable = [r for r in ranked if core_rank(r)[0] < 99 and has_num(r)]
    if not usable:
        return [], ranked, [c for _, _, c in CORE_ORDER]
    keep = usable[:hi]
    ids = {id(r) for r in keep}
    drop = [r for r in ranked if id(r) not in ids]
    # 不足 lo 行时不再从脏行里凑——宁可这件只有 2 行，也不拿垃圾行充数。
    return keep, drop, [c for _, _, c in CORE_ORDER]


# —— 表格定位三道闸门（V003 抓错页事故后加）——
# 事故复盘：AM2431 共 282 页，第 6 章 Specifications（p101~p116）才有参数表，
# 老 scan3 只扫前 40 页，真表整整被漏掉 60 多页；前 40 页里 p14 是
# Pin Attributes 的**术语解释**，正文写着 "For more information, see ... in
# Electrical Characteristics"，宽松标题正则把这句章节交叉引用当成表标题，
# parse_page 再把术语条目当 label，pick_core 最后凑满 5 行 —— 三处叠加，
# 于是 5 行纯文字进了草稿。下面三道闸门分别堵这三处。
NUMCOL_RX = re.compile(r"\b(MIN|TYP|MAX|NOM)\b", re.I)
KIND_TITLE_RX = re.compile(
    r"(absolute\s+)?maximum\s+ratings|recommended\s+operating\s+conditions"
    r"|(electrical|dc\s+electrical|static|dc)\s+(characteristics|specifications)",
    re.I)
REF_RX = re.compile(
    r"\b(see|refer|refer\s+to|for\s+more\s+information|defined\s+in|"
    r"described\s+in|in\s+section|appropriate|values\s+in|table\s+is|"
    r"which\s+.{0,40}\btable\b)\b", re.I)
TOC_PAGE_LIMIT = 10        # 目录只可能在最前面，正文页不参与目录判定

# —— 表头结构判据（Reviewer 2026-11-12 指出旧版只看「页面出现 >=2 个
# MIN/MAX 字样」太松：正文里反复提 minimum / maximum 也会误放行）——
# 真表的表头词在 PDF 文本层里是**竖排独立短行**：
#   p101: PARAMETER / MIN / MAX / UNIT
#   p105: SUPPLY NAME / DESCRIPTION / MIN(1) / NOM / MAX(1) / UNIT
# 而正文句子 "The MIN and MAX values ..." 中的词嵌在长行里，
# 一个独立列词行都没有。用「独立成行 + 表头标记词」当结构化证据。
HEADER_WORD_RX = re.compile(
    r"(?i)^(MIN|MAX|TYP|NOM|UNIT|VALUE|PARAMETER|DESCRIPTION|"
    r"SUPPLY\s+NAME|TEST\s+CONDITIONS)(\(\d+\))?\.?$")
NUM_HEAD_WORDS = {"MIN", "TYP", "MAX", "NOM", "VALUE"}
MARK_HEAD_WORDS = {"UNIT", "PARAMETER", "DESCRIPTION", "SUPPLY NAME",
                   "TEST CONDITIONS"}
HEADER_WINDOW = 8

# Reviewer 第三轮追加的四个极端场景：页上别处有表头、标题只是正文里的词、
# 有边框但前两行不是表头，都不能把整页放行。文本层表头因此必须与
# **独立成行的参数表标题**紧邻，且标题与表头之间不能夹着数据行。
# 注意 V003 的 p106 是跨页续表，页面上根本没有标题行：它靠下面的
# 边框判据进来，所以边框路径不能要求标题存在，否则会误杀真表。
TITLE_LINE_RX = re.compile(
    r"^\s*(?:\d+(?:\.\d+)*\s+)?"
    r"(?:absolute\s+maximum\s+ratings|maximum\s+ratings"
    r"|recommended\s+operating\s+conditions"
    r"|(?:electrical|dc\s+electrical|static|dc)\s+"
    r"(?:characteristics|specifications))"
    r"(?:\s*[-(].{0,40})?\s*$", re.I)
TITLE_MAX_GAP = 4
DATA_ROW_RX = re.compile(r"[-+]?\d+\.\d+|[-+]\d+(?:\s|$)")
BORDER_MARK_RX = re.compile(
    r"\b(PARAMETER|DESCRIPTION|SUPPLY\s+NAME|TEST\s+CONDITIONS)\b", re.I)


def title_anchor_lines(text):
    """页面里「独立成行的参数表标题」所在行号（0 基）。

    'Stresses beyond those listed under Absolute Maximum Ratings may ...'
    这种把标题词嵌进句子的正文行不算标题，整行必须基本就是标题本身
    （允许前导章节号和尾部短括注 / 破折号说明）。
    """
    lines = [" ".join(ln.split()) for ln in (text or "").splitlines()]
    return [i for i, ln in enumerate(lines)
            if ln and TITLE_LINE_RX.match(ln) and not REF_RX.search(ln)]


def _looks_like_data_row(line):
    return bool(DATA_ROW_RX.search(line))


def has_table_header(text, title_positions=None, max_gap=TITLE_MAX_GAP):
    """MIN/MAX 是否真的以「列名」身份出现在表头结构里。

    在任意连续 HEADER_WINDOW 行的窗口内，要求至少 2 个不同的数值列词
    各自独立成行，且窗口内还有 UNIT / PARAMETER / DESCRIPTION /
    SUPPLY NAME / TEST CONDITIONS 之一作为表头标记。
    纯正文（含多少 MIN/MAX 词汇都算）不满足，返回 False。

    `title_positions` 传入后（prescan3 用），表头窗口还必须紧跟
    title_anchor_lines() 找到的独立标题行：距离不超过 max_gap 行，
    且标题与窗口之间不能夹着参数数据行。单独调用本函数时
    title_positions=None，保持旧的纯文本契约不变。
    """
    lines = [" ".join(ln.split()) for ln in (text or "").splitlines()]
    tags = []
    for ln in lines:
        m = HEADER_WORD_RX.match(ln.strip())
        tags.append(" ".join(m.group(1).upper().split()) if m else None)
    for i in range(len(tags)):
        # 带锚点时，窗口必须从「第一个表头词行」起算。否则窗口起点可以
        # 退到标题后第 1 行，把 i - p 算成 1，页尾无关表格的 MIN/MAX
        # 就会借着标题的距离被放行（Reviewer 场景 a 实测抓到过一次）。
        if title_positions is not None and tags[i] is None:
            continue
        win = [w for w in tags[i:i + HEADER_WINDOW] if w]
        nums = {w for w in win if w in NUM_HEAD_WORDS}
        if len(nums) < 2 or not any(w in MARK_HEAD_WORDS for w in win):
            continue
        if title_positions is None:
            return True
        for p in title_positions:
            if (0 <= i - p <= max_gap and
                    not any(_looks_like_data_row(lines[j])
                            for j in range(p + 1, i))):
                return True
    return False


def _table_header_from_borders(page):
    """有表格边框时，直接看表头区域单元格里有没有 >=2 个数值列词。

    这是文本判据之外的第二条结构化证据。老手册的点线式 AMR 表没有边框，
    所以两条是「或」关系，不是「与」—— 不能把无边框的真表误杀。
    """
    try:
        tables = page.find_tables().tables
    except Exception:
        return False
    for t in tables:
        try:
            head = t.extract()[:2]
        except Exception:
            continue
        words = " ".join(str(c or "") for row in head for c in row).upper()
        nums = {w for w in ("MIN", "TYP", "MAX", "NOM", "VALUE")
                if re.search(r"\b%s\b" % w, words)}
        # 光有 MIN/MAX 不够：无关表格（PIN / MIN / MAX / UNIT）也有两列词。
        # 真参数表的表头一定还有 PARAMETER / DESCRIPTION / SUPPLY NAME /
        # TEST CONDITIONS 之一，这是把「无关表格」挡在候选页外的关键。
        if len(nums) >= 2 and BORDER_MARK_RX.search(words):
            return True
    return False


def prescan3(doc, npages, max_pages=0):
    """全书文本快筛：只留「有表标题词 + 真实表头结构」的页。

    为什么分两阶段：find_tables()/parse_page() 对 282 页全做一遍很慢，
    get_text("text") 是纯文本，全书扫一遍几乎不耗时；只有过了文本关的
    少数页才值得做边框取证。

    两层判据：
      1. NUMCOL_RX 快筛 —— 页面至少 2 个数值列词，且出现表标题词；
      2. has_table_header(t) 或 _table_header_from_borders(page) ——
         这些词必须真的以列名身份出现在表头结构里。
    V003 p14 的 Pin Attributes 术语解释页两层都过不了。
    max_pages=0 表示全书；调试时可传小值做回归。
    """
    limit = npages if max_pages <= 0 else min(npages, max_pages)
    cand = []
    for pno in range(1, limit + 1):
        page = doc.load_page(pno - 1)
        t = page.get_text("text")
        if not t.strip():
            continue
        if len(NUMCOL_RX.findall(t)) < 2 or not KIND_TITLE_RX.search(t):
            continue
        # 文本层表头必须锚在独立标题行附近；边框表头走独立判据，
        # 这样 p106 那种「标题在上一页」的跨页续表仍能进候选页。
        anchors = title_anchor_lines(t)
        if has_table_header(t, anchors) or _table_header_from_borders(page):
            cand.append(pno)
    return cand


def find_headings3(rows, kind):
    """标题行 → [(y, 行文本)]，并排除章节交叉引用句。

    X.find_headings 只返回 y，会把 "see ... in Electrical Characteristics"
    整句算命中。真表标题是独立短行（如 "6.1 Absolute Maximum Ratings"），
    引用句是长句且带 see/refer/for more information，必须排掉。
    """
    rx = re.compile(X.HEADING[kind], re.I)
    out = []
    for r in rows:
        line = " ".join(w[4] for w in r["w"]).strip()
        if not rx.search(line):
            continue
        if len(line) > 90 or REF_RX.search(line):
            continue
        out.append((r["y"], line))
    return out


def scan3(doc, npages, max_scan_pages=0):
    """全书候选页扫描：先文本快筛，再只对候选页做表格解析。

    返回 (hits, nav)，结构与 B.scan 一致，只是 key 多了 "ROC"。
    与老版三点不同：
      1. 不再被 MAX_SCAN_PAGES=40 截断（V003 真表在 p101）；
      2. 候选页必须同时出现标题词与 MIN/TYP/MAX/NOM 列词；
      3. 标题必须是独立短行，排除 see/refer 之类的章节交叉引用。
    目录页仍排除，但只在最前 10 页判：p102 这类续表正文会同时出现
    AMR/ELC/ROC 字样，若沿用「同页命中 3 种即跳过」会误杀真表。
    """
    hits = {k: [] for k in KINDS}
    nav = {k: [] for k in KINDS}
    for pno in prescan3(doc, npages, max_scan_pages):
        page = doc.load_page(pno - 1)
        rows = X.group_lines(X.dedup(page.get_text("words")))
        found = {k: find_headings3(rows, k) for k in KINDS}
        if pno <= TOC_PAGE_LIMIT and sum(1 for v in found.values() if v) >= 3:
            continue                      # 目录页
        for kind in KINDS:
            hs = found.get(kind) or []
            if not hs:
                continue
            bbs = X.table_bboxes(page)
            for h_y, _htext in hs:
                bb = X.choose_bbox(bbs, h_y)
                recs, _ = X.parse_page(page, kind, bbox=bb)
                good = [r for r in recs if r.get("label")]
                if not any(n[0] == pno for n in nav[kind]):
                    nav[kind].append((pno, h_y, bb, len(good)))
                for r in good:
                    hits[kind].append((B.rank(r), pno, r, h_y, bb))
    return hits, nav


def mark_dups(rows):
    """同一符号出现多组不同取值时提醒人工。

    V319 就是实例：两行都写 TA，一行 -40~85、一行 -55~125。
    真实手册里这是温度等级不同（商用/工业/军品）或 VLM 把 Tstg 误标成 TA，
    机器分不清哪种，也不该替人决定——只在 notes 里点出来，让人看一眼左图。
    """
    seen = {}
    for r in rows:
        sym = (r.get("symbol") or "").strip().upper()
        if not sym:
            continue
        vals = tuple((r.get(k) or "").strip()
                     for k in ("min_value", "typ_value", "max_value"))
        seen.setdefault(sym, []).append((r, vals))
    for sym, items in seen.items():
        if len(items) < 2:
            continue
        uniq = {v for _, v in items}
        if len(uniq) < 2:            # 完全重复的行，同样值得提醒
            for r, _ in items[1:]:
                r["notes"] = (r.get("notes", "")
                              + "；与上一行完全重复，可能该删").strip("；")
            continue
        for r, _ in items:
            r["notes"] = (r.get("notes", "")
                          + "；%s 有多组取值（疑不同温度等级或 VLM 误标），请确认"
                          % sym).strip("；")
    return rows


def value_flags(r):
    """数值列自身的坏味道。返回问题描述列表，非空即判 low_confidence。

    为什么置信度公式抓不到这些：公式只问"这个串在页面上找不找得到"，
    而 `V_O =`、`V_DD +` 这类**截断残留**恰恰是从页面上原样抠下来的，
    找得到，于是照样满分。但它们已经不是数值了，必须单独拦。

    实测来源（第一批）：
      V173 `Continuous output current` min=`V_O =`  —— 条件被抄进 min 列
      V345 `V_FBX to AGND` max=`V_DD +`            —— 公式被截断，丢了 0.3
    """
    issues = []
    for col, cn in (("min_value", "min"), ("typ_value", "typ"), ("max_value", "max")):
        v = (r.get(col) or "").strip()
        if not v:
            continue
        if "=" in v:
            issues.append("%s 列含等号，疑把条件抄进数值" % cn)
        elif re.search(r"[+\-*/]\s*$", v) and not re.fullmatch(r"[+\-]\d+(\.\d+)?", v):
            issues.append("%s 列以运算符结尾，疑被截断" % cn)
        elif not re.search(r"\d", v) and not re.match(r"(?i)^see\b", v):
            issues.append("%s 列没有数字" % cn)
    return issues


def det_score3(doc, r, cache):
    """确定性证据分（0-1）。每一项都能被人复算，不依赖模型自报。

    与 Batch 2 的差别只一处：v1.6 的验证器把 `normalize()` 拆成了
    `unify/collapse/nos` 三个函数，单位核对改用 `check_unit()`，
    它还会区分"独立出现"和"只作为更长串的一部分"（后者只降分不判错）。
    """
    import validate_annotation as V

    try:
        pno = int(r["evidence_page"])
    except (TypeError, ValueError):
        return 0.30
    if pno not in cache:
        cache[pno] = V.collapse(doc.load_page(pno - 1).get_text("text"))
    txt = cache[pno]

    vals = [r.get("min_value"), r.get("typ_value"), r.get("max_value")]
    vals = [v for v in vals if v]
    hit = 0
    for v in vals:
        rx = V.num_pattern(v)
        if rx and rx.search(txt):
            hit += 1

    s = 0.50
    if vals and hit == len(vals):
        s += 0.25
    elif hit:
        s += 0.10
    else:
        s -= 0.10

    unit = (r.get("unit") or "").strip()
    if unit:
        verdict, _why = V.check_unit(unit, txt)
        s += {"OK": 0.10, "SUSPECT": 0.03}.get(verdict, -0.10)

    sym = (r.get("symbol") or "").strip()
    # 允许下划线：`V_IH` 是手册里的真实写法
    if sym and re.fullmatch(r"[A-Za-z\u0394][A-Za-z0-9()/_\-±.\u0394]{1,11}", sym):
        s += 0.05

    name = (r.get("parameter_name") or "").strip()
    if 6 <= len(name) <= 60:
        s += 0.05
    if "=" in name:              # 把条件当参数名是典型坏行
        s -= 0.15
    if not name:
        s -= 0.20
    # 我们自己按规则清空的 symbol 不再倒扣，否则等于因规范化二次惩罚
    if not sym and not r.get("_sym_cleared"):
        s -= 0.05
    return max(0.0, min(1.0, s))


def score_rows3(doc, rows):
    """补置信度。最终分只取确定性证据分——VLM 自报分实测恒为 1.00，
    掺进公式只会给所有行统一加 0.3，反而抹平区分度（Batch 2 已验证）。
    自报分仍写在 notes 里备查。"""
    cache = {}
    for r in rows:
        det = det_score3(doc, r, cache)
        r["confidence_score"] = "%.2f" % round(min(0.95, det), 2)
    return rows


def build_js(rows, export_name):
    """把批次名注入前端，导出文件不再一律叫 Batch2_ANNOTATED.csv。

    I2.build_js() 会把 _b2_app.js 里的 __DRAFT__/__THRESH__ 换成实值；
    这里在它前面加一行 window.B3_EXPORT_NAME，前端的 EXPORT_NAME 就会用它。
    不改 I2 本身，Batch 2 生成器的行为完全不变（读不到这个变量时退回默认名）。
    """
    import json
    return ("window.B3_EXPORT_NAME=%s;\n" % json.dumps(export_name)
            + I2.build_js(rows))


def one_sample(meta, args):
    """处理一件：定位表格 → 裁剪 → VLM → 收敛 → 打分 → 留 3~5 行。"""
    sno = meta["sample_no"]
    path = Path(meta["file_path"])
    fname = path.name
    npages = int(meta["page_count"])
    pdf_url = "file:///" + str(path).replace("\\", "/")

    doc = fitz.open(str(path))
    hits, nav = scan3(doc, npages)
    out_dir = REPORTS / sno
    out_dir.mkdir(parents=True, exist_ok=True)

    panes, rows = [], []
    for kind in KINDS:
        if not nav.get(kind):
            continue
        withrows = [c for c in nav[kind] if c[3] > 0]
        if withrows:
            pno, hy, bb, _n = max(withrows, key=lambda c: (c[3], -c[0]))
        else:
            pno, hy, bb, _n = min(nav[kind], key=lambda c: c[0])
        png = out_dir / ("b3_%s_p%04d.png" % (kind, pno))
        page = doc.load_page(pno - 1)
        rect, used = B.render_clip(page, hy, bb, png)
        lines = I2.lines_in_rect(page, rect)

        vrows, vmeta = [], {}
        if not args.no_vlm:
            try:
                vrows, vmeta = vl_extract(png)
            except Exception as e:
                vmeta = {"error": "%s: %s" % (type(e).__name__, e)}

        pane_rows = []
        ptxt = I2.page_text(page)
        for vr in vrows:
            row = {
                "sample_no": sno, "file_name": fname,
                "evidence_page": str(pno), "table_title": KIND_CN[kind],
                "symbol": vr["symbol"],
                "parameter_name": vr["parameter_name"],
                "min_value": vr["min_value"], "typ_value": vr["typ_value"],
                "max_value": vr["max_value"], "unit": vr["unit"],
                "condition": "",
                "row_status": "DRAFT_AWAITING_HUMAN_CONFIRM",
                "notes": "VLM 草稿，须对左图核；vlm自报=%.2f" % vr["vlm_confidence"],
                "reviewer": "",
            }
            pane_rows.append(row)

        if not pane_rows:      # VLM 空手而归时退回文本表格解析，别让页面白给
            pane_rows = B.to_rows(sno, fname, kind, hits.get(kind, []))
            for r in pane_rows:
                r["notes"] = (r.get("notes", "")
                              + "；VLM 无结果，退回文本表格解析").strip("；")

        for r in pane_rows:
            I2.sanitize_row(r, ptxt)
            I2.repair_name(r)
        rows.extend(pane_rows)

        panes.append({"kind": kind, "pno": pno,
                      "rel": png.relative_to(PREP).as_posix(),
                      "bbox": used, "lines": lines,
                      "vmeta": vmeta, "use_vl": bool(vrows),
                      "span": sorted({n[0] for n in nav[kind]})})

    score_rows3(doc, rows)          # 必须在 close 之前，det_score 要读页文本
    doc.close()

    # —— 只留核心 3~5 行 ——
    keep, drop, _ = pick_core(rows)
    mark_dups(keep)

    # low_confidence 标记：低于阈值的行在 notes 里打词，方便 Excel 筛。
    for r in keep:
        try:
            low = float(r.get("confidence_score") or 0) < THRESH
        except ValueError:
            low = True
        bad = value_flags(r)
        if bad:
            low = True
            r["notes"] = (r.get("notes", "") + "；" + "；".join(bad)).strip("；")
        if low and WARN not in r.get("notes", ""):
            r["notes"] = (r.get("notes", "") + " | " + WARN).strip(" |")

    nlines = sum(len(p["lines"]) for p in panes)
    nlow = sum(1 for r in keep if WARN in r.get("notes", ""))
    if not panes:
        quality, note = "未定位", "全书未找到带 MIN/TYP/MAX 列的参数表，需人工翻查"
    elif nlines == 0:
        quality = "无文本层"
        note = "页面抓不到文字（纯图形/扫描），建议整件标 EXCLUDED"
    elif not keep:
        # 术语解释页/线图/错表：全部行都不是「带数值的核心参数」，
        # 此时绝不能交草稿给人，直接给 EXCLUDED 建议。
        quality, note = ("无法定位参数表",
                         "定位到 %d 页但没抽到任何带数值的核心参数行；"
                         "建议整件标 EXCLUDED: 表格定位失败/无标准参数表"
                         % len(panes))
    elif nlow:
        quality, note = "需重点看", "核心 %d 行中 %d 行 low_confidence，先核这些" % (len(keep), nlow)
    else:
        quality, note = "好", "核心 %d 行置信度均 ≥%.2f" % (len(keep), THRESH)

    card = {"sno": sno, "fname": fname, "npages": npages, "pdf": pdf_url,
            "panes": panes, "rows": keep, "quality": quality, "note": note,
            "dropped": len(drop), "nlow": nlow,
            "stratum": meta.get("stratum_proposed", "")}
    return keep, card


def main():
    ap = argparse.ArgumentParser(description="Batch 3 草稿 + 圈选台")
    ap.add_argument("--samples", default=",".join(BATCH1),
                    help="逗号分隔的 sample_no；默认第一批 6 件")
    ap.add_argument("--out-prefix", default="Batch3",
                    help="输出文件名前缀，默认 Batch3")
    ap.add_argument("--no-vlm", action="store_true",
                    help="不调视觉模型，只用文本表格解析（调试用）")
    args = ap.parse_args()
    want = [s.strip() for s in args.samples.split(",") if s.strip()]

    meta_all = {r["sample_no"]: r for r in
                csv.DictReader(open(WORKING, encoding="utf-8-sig"))}
    todo = []
    for s in want:
        if s in DONE:
            print("跳过 %s：Batch 2 已定稿" % s)
            continue
        if s not in meta_all:
            print("警告 %s：不在 Gold_Set_v1.1_WORKING.csv 里，跳过" % s)
            continue
        todo.append(meta_all[s])

    rows_out, cards = [], []
    for meta in todo:
        print("  ... %s" % meta["sample_no"], end="", flush=True)
        got, card = one_sample(meta, args)
        rows_out.extend(got)
        cards.append(card)
        print(" → 核心 %d 行（low=%d，丢弃 %d）"
              % (len(got), card["nlow"], card["dropped"]))

    out_csv = PREP / ("%s_DRAFT.csv" % args.out_prefix)
    out_html = PREP / ("%s_Viewer.html" % args.out_prefix)

    # utf-8-sig：Excel 靠 BOM 判编码，否则 ° µ − 会变 ?（中文 Windows 按 GBK 解码）
    with open(out_csv, "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=COLS)
        w.writeheader()
        for r in rows_out:
            w.writerow({k: r.get(k, "") for k in COLS})

    p = []
    p.append('<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">')
    p.append("<title>Batch 3 圈选台（左图右文）</title>")
    p.append("<style>%s%s</style></head><body>" % (B.CSS, I2.EXTRA_CSS))
    p.append("<header><h1>Batch 3 圈选台 · %d 件 · 核心参数草稿</h1>" % len(cards))
    p.append("<p>左边是原图，右边是同区域抓出的纯文本。"
             "页面下方已载入 <b>VLM 草稿</b>，每件只留最核心的 3~5 行；"
             "红底行是 <code>low_confidence</code>，请优先对图。</p></header>")
    p.append('<div class="wrap">')

    p.append('<div class="note"><h2>怎么用</h2><ul>'
             "<li>草稿<b>不是 Gold</b>。每一行都要对着左图核一遍再改状态。</li>"
             "<li>核过的行改 <code>CONFIRMED</code>；说不清的改 <code>UNRESOLVED</code>；"
             "不是参数（表头、注释）直接删。</li>"
             "<li><b>红底 = low_confidence</b>：数值在页面文本里没对上、或单位对不上、"
             "或模型自报很低。这些行最可能有错。</li>"
             "<li>草稿没覆盖的核心参数，用「新增空行」自己补。</li>"
             "<li>最后按「下载 CSV」。<b>不要用 Excel 另存</b>，会把编码变成 GBK。</li>"
             "</ul>"
             '<div class="hint">导出时会拦：状态 CONFIRMED 却没有数值的行、'
             "既无参数名又无符号的行。</div></div>")

    for c in cards:
        p.append('<div class="card"><div class="head">')
        p.append('<span class="sn">%s</span><span class="fn">%s</span>'
                 % (B.esc(c["sno"]), B.esc(c["fname"])))
        p.append('　<a href="%s" target="_blank">在 PDF 中打开</a>' % B.esc(c["pdf"]))
        cls = "t-ok" if c["quality"] == "好" else "t-warn"
        tags = ['<span class="tag %s">草稿：%s</span>' % (cls, B.esc(c["quality"]))]
        for pn in c["panes"]:
            tags.append('<span class="tag %s">%s = p%s</span>'
                        % ("t-amr" if pn["kind"] == "AMR" else "t-elc",
                           pn["kind"], "/".join(str(x) for x in pn["span"])))
        p.append('<div class="meta">共 %d 页 　%s</div>' % (c["npages"], "".join(tags)))
        p.append('<div class="meta">%s</div>' % B.esc(c["note"]))
        p.append('</div><div class="body">')

        if c["quality"] == "无文本层":
            p.append('<div class="err">本页抓不到任何文字（纯图形/扫描件）。'
                     "请整件标 <code>EXCLUDED: 无 OCR 能力，无法建立 Gold</code>。</div>")
        if c["quality"] == "无法定位参数表":
            p.append('<div class="err">全书未抽到任何带数值的核心参数行，'
                     '本件<b>不落草稿</b>。请整件标 '
                     "<code>EXCLUDED: 表格定位失败/无标准参数表</code>，"
                     "不要把术语解释、引脚说明当成参数行。</div>")
        for pn in c["panes"]:
            p.append('<div class="pane" data-sno="%s" data-fn="%s" data-page="%d" '
                     'data-title="%s">'
                     % (B.esc(c["sno"]), B.esc(c["fname"]), pn["pno"],
                        B.esc(KIND_CN[pn["kind"]])))
            p.append('<div class="cols"><div class="left">'
                     '<a href="%s" target="_blank"><img src="%s" alt="%s p%d"></a>'
                     '<div class="cap">%s · 第 %d 页%s</div></div>'
                     % (B.esc(pn["rel"]), B.esc(pn["rel"]), B.esc(c["sno"]),
                        pn["pno"], B.esc(KIND_CN[pn["kind"]]), pn["pno"],
                        "（按表格边框裁剪）" if pn["bbox"] else "（按标题位置裁剪）"))
            p.append('<div class="right"><div class="rh">点下面任意一行 → 自动填字段'
                     '<span class="cnt">%d 行</span></div><ol class="lines">'
                     % len(pn["lines"]))
            for ln in pn["lines"]:
                p.append('<li class="line" data-t="%s">%s</li>'
                         % (B.esc(ln), B.esc(ln)))
            p.append("</ol></div></div></div>")

        if c["rows"]:
            p.append('<div class="dh">本件核心草稿 %d 行（另有 %d 行非核心未载入）；'
                     '<span class="pill ok">绿 ≥%.2f</span> '
                     '<span class="pill low">红 &lt;%.2f = low_confidence</span></div>'
                     % (len(c["rows"]), c["dropped"], THRESH, THRESH))
        p.append("</div></div>")

    p.append('<div class="work"><h2>标注编辑区　<span id="cnt">0</span></h2>')
    p.append('<div class="filter">'
             '<label>样本 <select id="fsample"></select></label>'
             '<label><input type="checkbox" id="fnum"> 只看有数值的行</label>'
             '<label><input type="checkbox" id="ftodo"> 只看未确认的行</label>'
             '<button class="ghost" onclick="addBlank()">新增空行</button>'
             '<button class="ghost" onclick="dropNoName()">删掉无参数名的行</button>'
             '<button class="ghost" onclick="resetDraft()">恢复机器草稿</button>'
             '<label class="imp">导入上次的 CSV <input type="file" id="fimp" accept=".csv"></label>'
             "</div>")
    p.append('<div id="stat" class="stat"></div>')
    p.append('<table class="rows" id="tbl"><thead><tr>'
             "<th>样本</th><th>页</th><th>符号</th><th>参数名</th><th>min</th>"
             "<th>typ</th><th>max</th><th>单位</th><th>状态</th><th>草稿分</th>"
             "<th></th></tr></thead><tbody id=\"tbody\"></tbody></table>")
    p.append('<div class="bar"><button onclick="downloadCSV()">下载 CSV（UTF-8 带 BOM）</button>'
             '<button onclick="copyOut()" class="dl">复制 CSV</button> '
             '<label style="font-size:12.5px;margin-left:8px">'
             '<input type="checkbox" id="dropEmpty" checked> 导出时丢掉无值行/无参数名行</label>'
             '<span id="msg" class="msg"></span></div>')
    p.append('<textarea id="out" readonly></textarea>')
    p.append("</div>")
    p.append("</div><script>%s</script></body></html>"
             % build_js(rows_out, args.out_prefix + "_ANNOTATED"))
    out_html.write_text("".join(p), encoding="utf-8", newline="\n")

    print("\n圈选台: %s (%.1f KB, %d 件)"
          % (out_html.name, out_html.stat().st_size / 1024, len(cards)))
    print("草稿  : %s (%d 行)" % (out_csv.name, len(rows_out)))
    for c in cards:
        print("  %-5s %-6s 核心=%d low=%d 丢弃=%d  %s"
              % (c["sno"], c["quality"], len(c["rows"]), c["nlow"],
                 c["dropped"], c["note"][:36]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
