#!/bin/bash
# 限流取证脚本：临时调整 error_log 级别 + 三组参数对照，跑完自动还原。
set -u
TS=$(date +%Y%m%d-%H%M%S)
V=/www/server/panel/vhost/nginx/dsb.0668xgwl.com.conf
Z=/www/server/panel/vhost/nginx/dsb/dsb-limit-req.conf
L=/www/wwwlogs/dsb.0668xgwl.com.error.log

cp "$V" "$V.bak-test-$TS"
cp "$Z" "$Z.bak-test-$TS"
echo "备份: $V.bak-test-$TS / $Z.bak-test-$TS"
echo

# 把 error_log 提到 warn（默认是 error，warn 级的 limiting requests 会被吞掉）
sed -i -E 's#^([[:space:]]*error_log[[:space:]]+/www/wwwlogs/dsb\.0668xgwl\.com\.error\.log);#\1 warn;#' "$V"
echo "=== error_log 行改动确认 ==="
grep -n "error_log" "$V" | grep dsb
nginx -t >/dev/null 2>&1 && nginx -s reload && echo "reload OK"
echo

hit() {  # $1=伪造IP  返回 HTTP 码
  curl -s -o /dev/null -w "%{http_code}" --noproxy "*" -k --max-time 15 \
    -H "Host: dsb.0668xgwl.com" -H "Content-Type: application/pdf" \
    -H "X-Forwarded-For: $1" -H "X-Real-IP: $1" \
    -X POST https://127.0.0.1/api/parse --data-binary "x"
}

run_case() {
  local name="$1" rate="$2" burst="$3" resetwait="$4"
  echo "############################################################"
  echo "## 参数组: $name   rate=$rate  burst=$burst"
  echo "############################################################"

  printf 'limit_req_zone $binary_remote_addr zone=dsb_parse:10m rate=%s;\n' "$rate" > "$Z"
  sed -i -E "s#limit_req zone=dsb_parse burst=[0-9]+ nodelay;#limit_req zone=dsb_parse burst=$burst nodelay;#g" "$V"
  echo "zone 文件: $(cat "$Z")"
  echo "vhost 引用: $(grep -c "burst=$burst" "$V") 处"
  if ! nginx -t >/dev/null 2>&1; then echo "!! nginx -t 失败，跳过"; return; fi
  nginx -s reload
  sleep "$resetwait"

  local before
  before=$(wc -l < "$L")

  echo
  echo "-- P1: 连发 6 次，每次换伪造 XFF --"
  local i
  for i in 1 2 3 4 5 6; do
    printf '   伪造 XFF=203.0.113.%d -> %s\n' "$i" "$(hit 203.0.113.$i)"
  done

  sleep 3
  echo "-- P2: 人手重试节奏（3 次，间隔 2 秒，无伪造头）--"
  for i in 1 2 3; do
    printf '   第 %d 次 -> %s\n' "$i" "$(hit 198.51.100.7)"
    sleep 2
  done

  sleep 3
  echo "-- P3: 双击+重选（3 次，间隔 0.3 秒）--"
  for i in 1 2 3; do
    printf '   第 %d 次 -> %s\n' "$i" "$(hit 198.51.100.8)"
    sleep 0.3
  done

  echo
  echo "-- 本组新增 nginx 日志（limiting requests）--"
  tail -n +$((before + 1)) "$L" | grep -i "limiting requests" | sed 's/^/   /' || echo "   (无)"
  echo
}

run_case "A-当前线上" "10r/m" 2 40
run_case "B-中间值偏低" "2r/s" 5 6
run_case "C-中间值偏高" "5r/s" 10 6

echo "############################################################"
echo "## 还原"
echo "############################################################"
cp "$V.bak-test-$TS" "$V"
cp "$Z.bak-test-$TS" "$Z"
nginx -t 2>&1 | tail -1
nginx -s reload && echo "reload OK"
echo "--- 还原后确认 ---"
grep -n "error_log" "$V" | grep dsb
cat "$Z"
grep -n "limit_req zone" "$V"
echo
echo "--- 还原后存活复验 ---"
for h in dsb.0668xgwl.com harness.example.com site-b.example; do
  printf '   %-24s -> %s\n' "$h" "$(curl -s -o /dev/null -w '%{http_code}' --noproxy '*' -k --max-time 8 -H "Host: $h" https://127.0.0.1/)"
done
