最小核验包 audit_minimal_v28.zip —— 拼接、校验、核对步骤
================================================================================

包内 7 个文件（4 个源码/差异 + 3 个说明）：
    verify_reviewer.py                    P1/P2/P3 实现本体（v2.8）
    test_verify_reviewer.py               81 项定向回归用例
    verify_reviewer_v2.7_to_v2.8.diff     本轮增量（5 hunk，+54 -28）
    verify_reviewer_v2.3_to_v2.8.diff     自 v2.3 起累计（12 hunk，+360 -81）
    SHA256SUMS.txt                        上述 4 个文件的 sha256
    README_PIECES.txt                     本文件
    V28_CHANGES.txt                       两处修复的说明与证据

本包不含数据文件、不含 b64 分块。数据侧 8 个哈希以主包 manifest.sha256 为准。

--------------------------------------------------------------------------------
一、zip 自身的字节数与 SHA-256
--------------------------------------------------------------------------------
    见本次交付说明。本文件不写 zip 自身哈希：写进去会改变 zip 内容，形成自指，
    永远对不上。请以交付说明中的值为准。

二、解压后逐文件核对
        unzip audit_minimal_v28.zip
        sha256sum -c SHA256SUMS.txt
    期望 4 行全部 OK（verify_reviewer.py / test_verify_reviewer.py / 两份 diff）。

三、跑一遍（需配合 stageA_data_v28.zip 的数据目录）
        unzip stageA_data_v28.zip -d <DATA>
        python verify_reviewer.py --dir <DATA>
        python test_verify_reviewer.py --data <DATA> --verifier verify_reviewer.py
    期望：主验证器 10/10 PASS、exit 0、OVERALL_PASS=true；
          用例 81 项，PASS=81 SKIP=0 FAIL=0（同卷环境）。
    若沙箱与数据不在同一卷，junction 无法创建，T7a/T7b 记 SKIP：
          共 81 项，PASS=79 SKIP=2 FAIL=0，退出码仍为 0。
    SKIP 不算 PASS，也不算被测代码失败；详见 V28_CHANGES.txt 第 3 节。

四、只看本轮改了什么
        cat verify_reviewer_v2.7_to_v2.8.diff
    5 个 hunk，全部落在：模块 docstring（新增 v2.8 段）、VERSION 常量、
    check_v8 的版本状态块与判定行、_is_absolute_like 的 docstring 与盘符正则。
    没有任何其他模块被顺带修改。

五、口径说明
    v2.7 的测试为 74 项（v2.6 基线 61 + T1 新增 12 + T10i 1）。
    v2.8 在 74 基础上新增 T10j/T10k（P2 盘符相对路径）与 T11a–T11e
    （P3 解耦），合计 81 项。70 是 v2.7 定稿过程中的中间版，不作任何基线。
================================================================================
